package Soner;

public interface Needs {
    void listBooks();
    boolean login(String username, String password);
}