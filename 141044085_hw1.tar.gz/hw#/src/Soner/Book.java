package Soner;

public class Book {
    private String name;
    private String author;
    private String isbn;
    private boolean issued;
    private User receiver;
    private int bookId;

    /**
     * Parametrized constructor for Database
     * @param name of the book
     * @param author of the book
     * @param isbn of the book
     * @param bookId of the book
     * @throws Exception if being tried to create with same book id which is
     *                      already on there
     */
    public Book(String name, String author, String isbn, int bookId)
            throws Exception {
        for (Book temp : Database.getBooks()) {
            if (bookId == temp.getBookId()) {
                throw new IllegalArgumentException("The book exists with same" +
                        " the book id.");
            }
        }
        this.name = name;
        this.author = author;
        this.isbn = isbn;
        this.bookId = bookId;
        Database.getBooks().add(this);
        //update on .csv
    }

    /**
     * * Parametrized constructor for Database
     * @param name of the book
     * @param author of the book
     * @param isbn of the book
     * @param bookId of the book
     * @param issued statues of the book
     * @param receiver of the book
     * @throws Exception if being tried to create with same book id which is
     *                      already on there
     */
    public Book(String name, String author, String isbn, int bookId,
                boolean issued, User receiver) throws Exception {
        this(name, author, isbn, bookId);
        this.issued = issued;
        this.receiver = receiver;
        Database.getIssuedBooks().add(this);
        //update on .csvy
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getIsbn()
    {
        return isbn;
    }

    public void setIsbn(String isbn)
    {
        this.isbn = isbn;
    }

    /**
     * Check if the book is issued
     * @return true if issued in succeed. Otherwise, false
     */
    public boolean isIssued()
    {
        return issued;
    }

    public void setIssued(boolean issued)
    {
        this.issued = issued;
    }

    public User getReceiver() {
        return receiver;
    }

    public void setReceiver(User receiver) {
        this.receiver = receiver;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    /**
     * Determine the book being indicated as the received one, not a copy
     * @param id The unique registration number by the library
     * @return true, if it's exactly matched. Otherwise, false.
     */
    public boolean sameBook(int id) {
        return this.getBookId() == id;
    }

    @Override
    public String toString() {
        return "Name: " + name + " Author: " + author + " ISBN: " + isbn +
                " Book Id: " + getBookId();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (! (obj instanceof Book)) { return false; }
        Book b = (Book) obj;
        /*return  b.getName().equals(this.getName()) &&
                b.getAuthor().equals(this.getAuthor()) &&
                b.getIsbn().equals(this.getIsbn()) &&
                b.getBookId() == this.getBookId();
       */
        return b.getIsbn().equals(this.getIsbn());
    }
}
