package Soner;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class Database implements Needs {
    private static ArrayList<Book> books;
    private static ArrayList<Librarian> librarians;
    private static ArrayList<User> users;
    private static ArrayList<Book> issuedBooks;
    static {
        books = new ArrayList<Book>();
        librarians = new ArrayList<Librarian>();
        users = new ArrayList<User>();
        issuedBooks = new ArrayList<Book>();

        /*------------Test Books----------------*/
        try {
            new Book("Rebecca", "Daphne Du Maurier",
                    "1101907878", 34324);
            new Book("Jane Eyre", "Charlotte Bronte",
                    "0141040386", 1);
            new Book("The Shack: Where Tragedy Confronts Eternity",
                    "William P. Young", "0964729237", 890);
        } catch (Exception e) {
            e.printStackTrace();
        }

        /*------------Test Users----------------*/
        try {
            new User("arora", "12345678",
                    "sinan", "elveren");
            new User("supersonic", "sifre****",
                    "soner", "akar");
        } catch (Exception e) {
            e.printStackTrace();
        }

        /*-----------Test Librarians-----------*/
        try {
            new Librarian("cikicuk", "passboypassgirl",
                    "john", "McCay");
            new Librarian("admin", "admin",
                    "adminname", "adminsurname");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private String username;
    private String password;
    private String name;
    private String surname;

    public static ArrayList<Book> getBooks() {
        return books;
    }

    public static void setBooks(ArrayList<Book> books) {
        Database.books = books;
    }

    ArrayList<Librarian> getLibrarians() {
        return librarians;
    }

    void setLibrarians(ArrayList<Librarian> librarians) {
        Database.librarians = librarians;
    }

    ArrayList<User> getUsers() {
        return users;
    }

    void setUsers(ArrayList<User> users) {
        Database.users = users;
    }

    public static ArrayList<Book> getIssuedBooks() {
        return issuedBooks;
    }

    public static void setIssuedBooks(ArrayList<Book> issuedBooks) {
        Database.issuedBooks = issuedBooks;
    }

    public String getUsername() {
        return username;
    }

    protected void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public static void updateCSV() {

    }
}