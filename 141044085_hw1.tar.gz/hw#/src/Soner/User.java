package Soner;

public class User extends Database {
    /**
     * Parametrized constructor for User
     * @param username of the admin
     * @param password of the admin
     * @param name of the admin
     * @param surname of the admin
     * @throws Exception if being tried to create with same username which is
     *                      already on there
     */
    public User(String username, String password, String name,
                String surname) throws Exception {
        for (User temp : this.getUsers()) {
            if (this.getUsername() != null &&
                    this.getUsername().equals(temp.getUsername())) {
                throw new IllegalArgumentException("The username is already " +
                        "exist.(User)");
            }
        }
        this.setUsername(username);
        this.setPassword(password);
        this.setName(name);
        this.setSurname(surname);
        this.getUsers().add(this);
        //update on .csv
    }

    /**
     * Def-Ctor
     */
    public User() {}

    /**
     * Receive a book from the library
     * @param b takes a book reference
     * @return true if taken in succeed. Otherwise, false
     */
    public boolean issueBook(Book b) {
        if (this.getBooks().contains(b) && ! b.isIssued()) {
            b.setIssued(true);
            b.setReceiver(this);
            this.getIssuedBooks().add(b);
            return true;
        }
        return false;
        //add into issue books array
        //update on .csv
    }

    /**
     * Returns the book to the library
     * @param b takes a book reference
     * @return true if taken in succeed. Otherwise, false
     */
    public boolean returnBook(Book b) {
        int bookId;
        for (Book temp : this.getIssuedBooks()) {
            if (this.getIssuedBooks().contains(temp)) {
                bookId = temp.getBookId();
                if (b.isIssued() && b.sameBook(bookId) &&
                        b.getReceiver().equals(this)) {
                    b.setIssued(false);
                    b.setReceiver(null);
                    this.getIssuedBooks().remove(b);
                    return true;
                }
            }
        }
        return false;

        //update on .csv
    }

    /**
     * List all books with issue knowledge, without receiver knowledge
     */
    @Override
    public void listBooks() {
        for (Book temp : this.getBooks()) {
            System.out.print(temp + " ");
            System.out.println("Issued: " + temp.isIssued());
        }

    }

    /**
     * Login the system with username and password to determine admin or user
     * @param username of the person logging in the system
     * @param password of the person logging in the system
     * @return true if deleted in succeed. Otherwise, false
     */
    @Override
    public boolean login(String username, String password) {
        for (int i = 0; i < this.getUsers().size(); ++i) {
            if(this.getUsers().get(i).getUsername().equals(username)
                    && this.getUsers().get(i).getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Name: " + getName() + " Surname: " + getSurname() +
                " Username: " + getUsername() + " Password: " + getPassword();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (! (obj instanceof User)) { return false; }
        User u = (User) obj;
        return u.getUsername().equals(this.getUsername()) &&
                u.getPassword().equals(this.getPassword());
    }
}
