package Soner;

public class Librarian extends Database {
    /**
     * Parametrized constructor for Librarian
     * @param username of the admin
     * @param password of the admin
     * @param name of the admin
     * @param surname of the admin
     * @throws Exception if being tried to create with same username which is
     *                      already on there
     */
    public Librarian(String username, String password, String name,
                     String surname) throws Exception {
        for (Librarian temp : this.getLibrarians()) {
            if (this.getUsername() != null &&
                    this.getUsername().equals(temp.getUsername())) {
                throw new IllegalArgumentException("The username is already " +
                        "exist.(Librarian)");
            }
        }
        this.setUsername(username);
        this.setPassword(password);
        this.setName(name);
        this.setSurname(surname);
        this.getLibrarians().add(this);
        //update on .csv
    }

    /**
     * Def-Ctor
     */
    public Librarian() {}

    /**
     * When an object of the book class is created, its object is put
     * into the general holder(static) of the type
     * @param b takes a Book reference
     */
    public void addBook(Book b) {
        // when the object created it's is already on there
        // update the modification on the its .csv file
    }

    /**
     * Removes the intended book
     * @param bookId is unique determiner for books
     * @return true if deleted in succeed. Otherwise, false
     */
    public boolean removeBook(int bookId) {
        for (Book temp : this.getBooks()) {
            if (temp.sameBook(bookId)) {
                this.getBooks().remove(temp);
                return true;
            }
        }
        return false;
        // update the modification on the its .csv file
    }

    /**
     * Add a book as issued
     * @param b takes a Book reference
     */
    public void addAsIssuedBook(Book b) {
        if (b != null && b.isIssued()) {
            this.getIssuedBooks().add(b);
        }
        // update the modification on the its .csv file
    }

    /**
     * When an object of the user class is created, its object is put
     * into the general holder(static) of the type
     * @param u takes user reference
     * @return true if created, successfully
     * @throws Exception bcz of the fact that the constructor is checked
     * whether same username exists, it is needed to be catched in a place
     * in which it is used
     */
    public boolean registerNewUser(User u) throws Exception {
       /* for (int i = 0; i < this.getUsers().size() - 1; ++i) {
            if (u.getUsers().get(i).getUsername().equals(
                    this.getUsers().get(i).getUsername())) {
                throw new IllegalArgumentException("The username is already " +
                        "exist.");
            }
        }*/
        return true;
        // update on .csv
    }

    /**
     * Delete intended user with regard to username by taking advantage of
     * its uniqueness
     * @param name takes a username
     * @return true if created, successfully. Otherwise, false
     */
    public boolean deleteUser(String name) {
        for (User temp : this.getUsers()) {
            if (name.equals(temp.getUsername())) {
                this.getUsers().remove(temp);
                return true;
            }
        }
        return false;
        // update on .csv
    }

    /**
     * List all books with issue knowledge, if issued, print receiver
     */
    @Override
    public void listBooks() {
        for (Book temp : this.getBooks()) {
            System.out.print(temp + " ");
            System.out.println("Issued: " + temp.isIssued() + " Receiver: " +
                    temp.getReceiver());
        }

    }

    /**
     * Print whole issued books
     */
    public void listIssuedBooks() {
        for (Book temp : this.getIssuedBooks()) {
            System.out.println(temp);
        }
    }

    /**
     * Print whole users with their information
     */
    public void listUsers() {
        for (User temp : this.getUsers()) {
            System.out.println(temp);
        }
    }

    /**
     * Print whole librarians with their information
     */
    public void listLibrarians() {
        for (Librarian temp : this.getLibrarians()) {
            System.out.println(temp);
        }
    }

    /**
     * Login the system with username and password to determine admin or user
     * @param username of the person logging in the system
     * @param password of the person logging in the system
     * @return true if deleted in succeed. Otherwise, false
     */
    @Override
    public boolean login(String username, String password) {
        for (int i = 0; i < this.getLibrarians().size(); ++i) {
            if(this.getLibrarians().get(i).getUsername().equals(username)
                    && this.getLibrarians().get(i).getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Name: " + getName() + " Surname: " + getSurname() +
                " Username: " + getUsername() + " Password: " + getPassword();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (! (obj instanceof Librarian)) { return false; }
        Librarian l = (Librarian) obj;
        return l.getUsername().equals(this.getUsername()) &&
                l.getPassword().equals(this.getPassword());
    }
}
