package Akar;

import Soner.Book;
import Soner.Database;
import Soner.Librarian;
import Soner.User;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        /* --- simple input part --- */
        /*
        Scanner sc = new Scanner(System.in);
        int input = 0;
        Database test = null;
        String username = null;
        String password = null;
        System.out.println("Login the system: enter 1 for librarian enter 2 " +
                "for user");
            input = sc.nextInt();
            sc.nextLine();
            System.out.println("Username: ");
            username = sc.nextLine();
            System.out.println("Password: ");
            password = sc.nextLine();


        switch (input) {
            case 1:
                test = new Librarian();
                if (test.login(username, password)) {
                    System.out.println("Login successfully");
                }
                else {
                    System.out.println("Failed to login");
                }
                break;
            case 2:
                test = new User();
                if (test.login(username, password)) {
                    System.out.println("Login successfully");
                }
                else {
                    System.out.println("Failed to login");
                }
            default:
                  System.out.println("Wrong input!");
        }
        */ // end simple input part

        /* --- test part --- */

        Database lib = null;
        Database user = null;
        Book b = null;
        Book b1 = null;
        try {
            lib = new Librarian("windows", "123",
                    "7", "Pro");
            user = new User("user", "pass",
                    "user", "pass");
            b = new Book("The Shack: Where Tragedy Confronts Eternity",
                    "William P. Young", "0964729237", 891);
        } catch (Exception e) {
            e.printStackTrace();
        }


        lib.listBooks();
        System.out.println("\nFor user ->\n");
        user.listBooks();
        //user.setPassword("sdsf");
        System.out.println("\n");
        Librarian reelib = (Librarian) lib;
        System.out.println("\nLibrarians ->\n");
        reelib.listLibrarians();
        System.out.println("\nUsers ->\n");
        reelib.listUsers();
        System.out.println("\nBooks ->\n");
        reelib.listBooks();

        /* same book cannot be added but copy
        *  I handle the circumstance
        */
        /*
        try {
            b = new Book("The Shack: Where Tragedy Confronts Eternity",
                    "William P. Young", "0964729237", 891);
        } catch (Exception e) {
            e.printStackTrace();
        }
        */
        System.out.println("\nBook list after added a new book  ->\n");
        try {
            b1 = new Book("Big Little Lies", "Liane Moriarty",
                    "0425274861", 435);
        } catch (Exception e) {
            e.printStackTrace();
        }
        reelib.listBooks();

        System.out.println("\nBook list after delete a book  ->\n");
        reelib.removeBook(b.getBookId());
        reelib.listBooks();

        System.out.println("\nUser list after added a user  ->\n");
        try {
            reelib.registerNewUser(new User("hap", "hup",
                    "ali", "veli"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        reelib.listUsers();

        System.out.println("\nUser list after delete a user  ->\n");
        reelib.deleteUser("arora");
        reelib.listUsers();

        System.out.println("\nBook list after add a user  ->\n");
        try {
            reelib.addBook(new Book("The Shack: Where Tragedy Confronts Eternity",
                    "William P. Young", "0964729237", 893));
        } catch (Exception e) {
            e.printStackTrace();
        }
        reelib.listBooks();

        User u = (User) user;

        System.out.println("\nUser issued a book  ->\n");
        u.issueBook(b);
        reelib.listIssuedBooks();

        System.out.println("\nIs the book issued  ->\n");
        System.out.println(b.isIssued());

        System.out.println("\nBook List with issue knowledge  ->\n");
        reelib.listBooks();

        System.out.println("\nWho is issuer?  ->\n");
        System.out.println(b.getReceiver());

        System.out.println("\nReturn a book  ->\n");
        u.returnBook(b);
        reelib.listIssuedBooks(); // free

        System.out.println("DONE..");


    }
}